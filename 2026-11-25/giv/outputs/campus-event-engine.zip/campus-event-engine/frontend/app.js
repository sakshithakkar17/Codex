const api = '/api';
const state = { category: '', freeOnly: false, tagged: false, search: '' };
const $ = (selector) => document.querySelector(selector);
const escapeHTML = (value = '') => String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));

async function request(path, options) {
  const response = await fetch(`${api}${path}`, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || 'Something went wrong.');
  return data;
}
function money(value) { return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(value || 0); }
function dateLabel(value) { return new Intl.DateTimeFormat('en-IN', { day: 'numeric', month: 'short' }).format(new Date(value)); }
function toast(message, error = false) {
  const el = $('#toast'); el.textContent = message; el.className = `toast show${error ? ' error' : ''}`;
  window.clearTimeout(toast.timer); toast.timer = window.setTimeout(() => { el.className = 'toast'; }, 2800);
}
function artwork(event) {
  if (event.category === 'Cultural') return ['art-music', '♫'];
  if (/workshop/i.test(event.title)) return ['art-workshop', '⚙'];
  return ['art-tech', '⌘'];
}

async function loadEvents() {
  const params = new URLSearchParams();
  if (state.category) params.set('category', state.category);
  if (state.freeOnly) params.set('freeOnly', 'true');
  if (state.tagged) params.set('tagged', 'true');
  if (state.search) params.set('search', state.search);
  const events = await request(`/events?${params}`);
  $('#allCount').textContent = events.length;
  $('#eventNavCount').textContent = String(events.length).padStart(2, '0');
  const grid = $('#eventGrid');
  if (!events.length) { grid.innerHTML = '<div class="empty">No events match those filters. Try another search.</div>'; return; }
  grid.innerHTML = events.map(event => {
    const [art, icon] = artwork(event);
    const tags = (event.tags || []).slice(0, 3).map(tag => `<span># ${escapeHTML(tag)}</span>`).join('');
    return `<article class="event-card">
      <div class="event-art ${art}"><span class="category-tag">${escapeHTML(event.category)}</span><span class="fee-tag">${event.entryFee === 0 ? 'FREE' : money(event.entryFee)}</span><span class="art-icon">${icon}</span></div>
      <div class="event-body"><div class="event-title">${escapeHTML(event.title)}</div><div class="event-club">Organized by ${escapeHTML(event.organizerClub)}</div>
      <div class="event-meta"><span>◷ ${dateLabel(event.date)}</span><span>⌖ ${escapeHTML(event.venue)}</span></div>
      <div class="event-tags">${tags}</div>
      <div class="event-bottom"><span class="seats"><b>${event.seatsAvailable}</b> seats left</span><button class="book-btn" data-book="${escapeHTML(event._id)}" ${event.seatsAvailable < 1 ? 'disabled' : ''}>${event.seatsAvailable < 1 ? 'Sold out' : 'Reserve spot →'}</button></div></div>
    </article>`;
  }).join('');
  grid.querySelectorAll('[data-book]').forEach(button => button.addEventListener('click', () => openBooking(button.dataset.book, events.find(item => item._id === button.dataset.book))));
}
async function loadAnalytics() {
  const [overview, departments, turnout] = await Promise.all([
    request('/analytics/overview'), request('/analytics/departments'), request('/analytics/turnout')
  ]);
  $('#statEvents').textContent = overview.eventCount;
  $('#statRegistrations').textContent = overview.registrationCount;
  $('#statCheckedIn').textContent = overview.checkedInCount;
  $('#statRevenue').textContent = money(overview.totalRevenue);
  const maxDepartment = Math.max(1, ...departments.map(row => row.totalRegistrations));
  $('#departmentList').innerHTML = departments.map(row => `<div class="department-row"><span>${escapeHTML(row._id)}</span><div class="bar-track"><div class="bar-fill" style="width:${row.totalRegistrations / maxDepartment * 100}%"></div></div><strong>${row.totalRegistrations}</strong></div>`).join('') || '<div class="empty">No registrations yet.</div>';
  const eventNames = Object.fromEntries((await request('/events')).map(event => [event._id, event.title]));
  $('#turnoutList').innerHTML = turnout.map(row => `<div class="turnout-row"><span class="turnout-name">${escapeHTML(eventNames[row.eventId] || row.eventId)}</span><span class="turnout-count">${row.checkedInCount}/${row.totalRegistrations} · ${Math.round(row.turnoutPercentage)}%</span><div class="turnout-bar"><i style="width:${Math.min(100, row.turnoutPercentage)}%"></i></div></div>`).join('') || '<div class="empty">No attendance yet.</div>';
}
async function refresh() {
  try { await Promise.all([loadEvents(), loadAnalytics()]); }
  catch (error) { $('#eventGrid').innerHTML = `<div class="empty">${escapeHTML(error.message)}<br><small>Start the backend and check your MongoDB connection.</small></div>`; }
}
function openBooking(id, event) {
  $('#bookingEventId').value = id;
  $('#bookingTitle').textContent = event.title;
  $('#bookingMessage').textContent = '';
  $('#bookingDialog').showModal();
}

$('#searchInput').addEventListener('input', event => {
  state.search = event.target.value.trim(); window.clearTimeout(loadEvents.timer); loadEvents.timer = window.setTimeout(() => loadEvents().catch(error => toast(error.message, true)), 250);
});
$('#categorySelect').addEventListener('change', event => {
  state.category = event.target.value; document.querySelectorAll('[data-category]').forEach(chip => chip.classList.toggle('active', chip.dataset.category === state.category));
  loadEvents().catch(error => toast(error.message, true));
});
document.querySelectorAll('[data-category]').forEach(chip => chip.addEventListener('click', () => {
  state.category = chip.dataset.category; $('#categorySelect').value = state.category;
  document.querySelectorAll('[data-category]').forEach(item => item.classList.toggle('active', item === chip));
  loadEvents().catch(error => toast(error.message, true));
}));
$('#freeFilter').addEventListener('click', event => {
  state.freeOnly = !state.freeOnly; event.currentTarget.classList.toggle('on', state.freeOnly);
  loadEvents().catch(error => toast(error.message, true));
});
$('#tagFilter').addEventListener('click', event => {
  state.tagged = !state.tagged; event.currentTarget.classList.toggle('active', state.tagged);
  loadEvents().catch(error => toast(error.message, true));
});
$('#refreshButton').addEventListener('click', () => refresh().then(() => toast('Campus data refreshed.')));
$('#bookingForm').addEventListener('submit', async event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const payload = Object.fromEntries(form.entries());
  payload.year = Number(payload.year);
  try {
    const result = await request(`/events/${encodeURIComponent($('#bookingEventId').value)}/book`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    $('#bookingDialog').close(); event.currentTarget.reset();
    toast(`Registration confirmed · ${result.registration.ticketId}`);
    await refresh();
  } catch (error) { $('#bookingMessage').textContent = error.message; }
});
$('#todayLabel').textContent = new Intl.DateTimeFormat('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' }).format(new Date());
refresh();
