# Campus Event Engine & Ticket Hub

A ready-to-run full-stack campus events project based on the attached MongoDB brief. It includes an Express + Mongoose backend, a responsive browser frontend, MongoDB seed data, atomic seat booking, check-in and sponsor updates, search filters, and aggregation analytics.

## Requirements

- Node.js 18 or newer
- MongoDB Community Server running locally, or a MongoDB Atlas connection string

## Run it in VS Code

1. Open this project folder in VS Code.
2. In the terminal, install dependencies:

   ```bash
   npm install
   ```

3. Make your local environment file:

   ```bash
   cp .env.example .env
   ```

   On Windows PowerShell use `Copy-Item .env.example .env`. Edit `.env` if your MongoDB connection string differs.
4. Seed the sample campus events and registrations:

   ```bash
   npm run seed
   ```

5. Start the app:

   ```bash
   npm run dev
   ```

6. Open [http://localhost:5000](http://localhost:5000).

The frontend and API are served from the same server. API health is available at `/api/health`.

## API routes

| Method | Route | Purpose |
| --- | --- | --- |
| GET | `/api/clubs` | List campus clubs. |
| GET | `/api/events` | List/search events. Supports `search`, `category`, `freeOnly=true`, and `tagged=true`. |
| GET | `/api/events/:id` | Get one event. |
| GET | `/api/registrations?department=Computer%20Science` | List registrations, optionally by department. |
| POST | `/api/events/:id/book` | Atomically reserve a seat and create a ticket. Body: `studentId`, `studentName`, `department`, `year`, optional `method`. |
| PATCH | `/api/registrations/:ticketId/check-in` | Mark a ticket checked in. |
| POST | `/api/events/:id/sponsors` | Add a sponsor without duplicates. Body: `{ "sponsor": "CloudInc" }`. |
| GET | `/api/analytics/overview` | Event, ticket, check-in, and revenue totals. |
| GET | `/api/analytics/revenue` | Revenue and ticket totals by event and organizer club. |
| GET | `/api/analytics/departments` | Registrations grouped by department. |
| GET | `/api/analytics/turnout` | Total registrations, checked-in count, and turnout percent by event. |

## Project files

- `backend/src/server.js` - API and server startup
- `backend/src/models.js` - MongoDB schemas for clubs, events, and registrations
- `backend/src/seed.js` - sample dataset based on the brief
- `frontend/index.html`, `frontend/styles.css`, `frontend/app.js` - frontend interface and interactions
- `.env.example` - safe configuration template; copy it to `.env`

## Push to GitHub

Create an empty repository on GitHub, then from this folder run:

```bash
git init
git add .
git commit -m "Build campus event engine"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the remote URL with your repository URL. `.env` and `node_modules` are excluded by `.gitignore`; do not commit database credentials.
